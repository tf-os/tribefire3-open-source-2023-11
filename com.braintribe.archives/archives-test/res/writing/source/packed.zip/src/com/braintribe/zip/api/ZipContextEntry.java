package com.braintribe.zip.api;

import java.util.zip.ZipEntry;

public interface ZipContextEntry {
	ZipEntry getZipEntry();
	byte [] getZipEntryPayload();
}
