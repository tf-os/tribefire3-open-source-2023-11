package com.braintribe.zip.api;

import com.braintribe.zip.impl.ZipContextImpl;

public class ZipUtil {
	public static ZipContext zip() {
		return new ZipContextImpl();
	}
	
}
