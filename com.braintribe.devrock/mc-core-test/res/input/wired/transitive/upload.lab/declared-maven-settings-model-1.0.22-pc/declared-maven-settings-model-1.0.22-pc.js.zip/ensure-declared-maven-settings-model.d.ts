/// <reference path="./declared-maven-settings-model.d.ts" />

export declare namespace meta {
	const groupId: string;
	const artifactId: string;
	const version: string;
}

export import PluginGroups = $T.com.braintribe.model.artifact.maven.settings.PluginGroups;
export import ActivationOS = $T.com.braintribe.model.artifact.maven.settings.ActivationOS;
export import Server = $T.com.braintribe.model.artifact.maven.settings.Server;
export import Configuration = $T.com.braintribe.model.artifact.maven.settings.Configuration;
export import RepositoryPolicy = $T.com.braintribe.model.artifact.maven.settings.RepositoryPolicy;
export import Activation = $T.com.braintribe.model.artifact.maven.settings.Activation;
export import ActivationProperty = $T.com.braintribe.model.artifact.maven.settings.ActivationProperty;
export import Profile = $T.com.braintribe.model.artifact.maven.settings.Profile;
export import ActivationFile = $T.com.braintribe.model.artifact.maven.settings.ActivationFile;
export import Repository = $T.com.braintribe.model.artifact.maven.settings.Repository;
export import Proxy = $T.com.braintribe.model.artifact.maven.settings.Proxy;
export import Mirror = $T.com.braintribe.model.artifact.maven.settings.Mirror;
export import Property = $T.com.braintribe.model.artifact.maven.settings.Property;
export import Settings = $T.com.braintribe.model.artifact.maven.settings.Settings;
