/// <reference path="../com.braintribe.gm.root-model-1.0~/root-model.d.ts" />
/// <reference path="../com.braintribe.devrock.mc-reason-model-1.0~/mc-reason-model.d.ts" />

declare namespace $T.com.braintribe.model.artifact.maven.settings {

	const Activation: $tf.reflection.EntityType<Activation>;
	interface Activation extends $T.com.braintribe.model.generic.GenericEntity {
		activeByDefault: boolean;
		file: ActivationFile;
		jdk: string;
		os: ActivationOS;
		property: ActivationProperty;
	}

	const ActivationFile: $tf.reflection.EntityType<ActivationFile>;
	interface ActivationFile extends $T.com.braintribe.model.generic.GenericEntity {
		exists: string;
		missing: string;
	}

	const ActivationOS: $tf.reflection.EntityType<ActivationOS>;
	interface ActivationOS extends $T.com.braintribe.model.generic.GenericEntity {
		arch: string;
		family: string;
		name: string;
		version: string;
	}

	const ActivationProperty: $tf.reflection.EntityType<ActivationProperty>;
	interface ActivationProperty extends $T.com.braintribe.model.generic.GenericEntity {
		name: string;
		value: string;
	}

	const Configuration: $tf.reflection.EntityType<Configuration>;
	interface Configuration extends $T.com.braintribe.model.generic.GenericEntity {
		any: string;
	}

	const Mirror: $tf.reflection.EntityType<Mirror>;
	interface Mirror extends $T.com.braintribe.model.generic.GenericEntity {
		mirrorOf: string;
		name: string;
		url: string;
	}

	const PluginGroups: $tf.reflection.EntityType<PluginGroups>;
	interface PluginGroups extends $T.com.braintribe.model.generic.GenericEntity {
		_pluginGroupList: $tf.List<string>;
	}

	const Profile: $tf.reflection.EntityType<Profile>;
	interface Profile extends $T.com.braintribe.model.generic.GenericEntity {
		activation: Activation;
		pluginRepositories: $tf.List<Repository>;
		properties: $tf.List<Property>;
		repositories: $tf.List<Repository>;
	}

	const Property: $tf.reflection.EntityType<Property>;
	interface Property extends $T.com.braintribe.model.generic.StandardIdentifiable {
		name: string;
		value: string;
	}

	const Proxy: $tf.reflection.EntityType<Proxy>;
	interface Proxy extends $T.com.braintribe.model.generic.GenericEntity {
		active: boolean;
		host: string;
		nonProxyHosts: string;
		password: string;
		port: $tf.Integer;
		protocol: string;
		username: string;
	}

	const Repository: $tf.reflection.EntityType<Repository>;
	interface Repository extends $T.com.braintribe.model.generic.GenericEntity {
		layout: string;
		name: string;
		releases: RepositoryPolicy;
		snapshots: RepositoryPolicy;
		url: string;
	}

	const RepositoryPolicy: $tf.reflection.EntityType<RepositoryPolicy>;
	interface RepositoryPolicy extends $T.com.braintribe.model.generic.GenericEntity {
		checksumPolicy: string;
		enabled: boolean;
		updatePolicy: string;
	}

	const Server: $tf.reflection.EntityType<Server>;
	interface Server extends $T.com.braintribe.model.generic.GenericEntity {
		configuration: Configuration;
		directoryPermissions: string;
		filePermissions: string;
		passphrase: string;
		password: string;
		privateKey: string;
		username: string;
	}

	const Settings: $tf.reflection.EntityType<Settings>;
	interface Settings extends $T.com.braintribe.model.generic.GenericEntity {
		activeProfiles: $tf.List<Profile>;
		interactiveMode: boolean;
		localRepository: string;
		mirrors: $tf.List<Mirror>;
		offline: boolean;
		origination: $T.com.braintribe.devrock.model.mc.cfg.origination.Origination;
		pluginGroups: $tf.List<string>;
		profiles: $tf.List<Profile>;
		proxies: $tf.List<Proxy>;
		servers: $tf.List<Server>;
		standardMavenCascadeResolved: boolean;
		usePluginRegistry: boolean;
	}

}

