This is the Terminal artifact for testing MC's behavior when it comes to a corrupt terminal pom. 

Terminal#1.0 

Result:
exception and warning 


you cannot install this artifact, test must be run on the working copy 
