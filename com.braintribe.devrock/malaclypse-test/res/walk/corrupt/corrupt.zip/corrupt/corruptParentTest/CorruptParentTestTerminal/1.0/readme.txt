This is the Terminal artifact for testing MC's behavior when it comes to corrupt parents. 
It tests :
- parent resolving
- dependency management 
- dependency inheritence


Terminal#1.0  <- Parent (corrupt))
	A#(parent mgnt)			
	
expected
 exception and error cause appearing in listener

cannot be installed, test must run on the working copy 