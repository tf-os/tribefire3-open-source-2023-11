This is the Terminal artifact for testing MC's behavior when it comes to corrupt poms

Terminal#1.0 
	A#1.0 - corrupt
	B#1.0		
	

expected solutions are
- no result, but the corrupt pom should show up in the monitor
	
you cannot install these artifacts, test must be run on working copy 
