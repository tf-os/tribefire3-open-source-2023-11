This is the Terminal artifact for testing MC's behavior when it comes to improper variable resolving. It tests encountering a variable that cannot be resolved. 

Terminal#1.0 
	A#1.0 (won't be able to resolve that as the version's missing)

execute this steps
ant -Dartifact=com.braintribe.test.dependencies.scopeTest:resolvingPerProperty#1.0 install